const WHATSAPP_NUMBER = '553192180872';
const STORAGE_PRODUCTS = 'de_products_v9';
const STORAGE_CART = 'de_cart_v9';
const STORAGE_ORDERS = 'de_orders_v9';

const defaultProducts = [
  { name: 'Trufa de Brigadeiro', price: 5, cat: 'Trufas', desc: 'Recheio clássico de brigadeiro, cremoso e chocolatudo.', available: true },
  { name: 'Trufa de Oreo', price: 5, cat: 'Trufas', desc: 'Creme suave com pedacinhos de Oreo.', available: true },
  { name: 'Trufa de Maracujá', price: 5, cat: 'Trufas', desc: 'Azedinho equilibrado com chocolate.', available: true },
  { name: 'Trufa de Coco', price: 5, cat: 'Trufas', desc: 'Coco cremoso com cobertura de chocolate.', available: true },
  { name: 'Trufa de Morango', price: 5, cat: 'Trufas', desc: 'Visível no cardápio, mas indisponível no momento.', available: false, locked: true },
  { name: 'Trufa de Uva', price: 5, cat: 'Trufas', desc: 'Visível no cardápio, mas indisponível no momento.', available: false, locked: true },
  { name: 'Combo 3 Trufas', price: 14, cat: 'Promoção', desc: 'Escolha 3 sabores disponíveis: Brigadeiro, Oreo, Maracujá ou Coco.', available: true },
  { name: 'Brownie Encantado', price: 8, cat: 'Brownies', desc: 'Produto à mostra para futura venda.', available: false },
  { name: 'Docinho Especial', price: 4, cat: 'Docinhos', desc: 'Produto à mostra para futura venda.', available: false }
];
const $ = s => document.querySelector(s);
const money = v => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
function loadProducts(){
  const saved = JSON.parse(localStorage.getItem(STORAGE_PRODUCTS) || 'null');
  const list = Array.isArray(saved) ? saved : defaultProducts;
  const fixed = list.filter(p => p.name !== 'Trufa de Ninho');
  defaultProducts.forEach(p => { if(!fixed.some(x => x.name === p.name)) fixed.push(p); });
  return fixed.map(p => ({...p, available: ['Trufa de Morango','Trufa de Uva','Brownie Encantado','Docinho Especial'].includes(p.name) ? false : p.available !== false}));
}
let products = loadProducts();
let cart = JSON.parse(localStorage.getItem(STORAGE_CART) || '[]');
function save(){localStorage.setItem(STORAGE_PRODUCTS, JSON.stringify(products)); localStorage.setItem(STORAGE_CART, JSON.stringify(cart));}
function toast(msg){const el=$('#toast'); if(!el)return; el.textContent=msg; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2200)}
function renderProducts(){
  const c=$('#products'); if(!c)return; c.innerHTML='';
  const category=$('#category')?.value || 'Todos'; const query=($('#search')?.value||'').toLowerCase();
  products.filter(p => (category==='Todos'||p.cat===category) && (p.name.toLowerCase().includes(query)||p.desc.toLowerCase().includes(query))).forEach((p)=>{
    const i=products.findIndex(x=>x.name===p.name); const ok=p.available!==false;
    const el=document.createElement('article'); el.className='product'+(ok?'':' unavailable');
    el.innerHTML=`<span class="tag">${p.cat}</span><span class="tag ${ok?'ok':'lock'}">${ok?'Disponível':'Indisponível'}</span><div class="product-emoji">${p.cat==='Promoção'?'🎁':p.cat==='Brownies'?'🍫':p.cat==='Docinhos'?'🧁':'🍬'}</div><h3>${p.name}</h3><p>${p.desc}</p><strong class="price">${money(p.price)}</strong><button class="btn ${ok?'secondary':'ghost'} full" ${ok?`onclick="addToCart(${i})"`:'disabled'}>${ok?'Adicionar ao pedido':'Indisponível'}</button>`;
    c.appendChild(el);
  });
  if(!c.innerHTML)c.innerHTML='<p>Nenhum produto encontrado.</p>';
}
function addToCart(i){ const p=products[i]; if(!p||p.available===false)return toast('Esse item está indisponível.'); const e=cart.find(x=>x.name===p.name); if(e)e.qty++; else cart.push({name:p.name,price:p.price,qty:1}); save(); renderCart(); toast(`${p.name} adicionado.`);}
function addCombo(){ const i=products.findIndex(p=>p.name==='Combo 3 Trufas'); if(i>=0)addToCart(i); }
function changeQty(i,d){ if(!cart[i])return; cart[i].qty+=d; if(cart[i].qty<=0)cart.splice(i,1); save(); renderCart();}
function clearCart(){cart=[]; save(); renderCart();}
function renderCart(){ const box=$('#cartItems'), total=$('#total'); if(!box)return; box.innerHTML=''; let sum=0; if(!cart.length)box.innerHTML='<p class="mini">Seu carrinho está vazio.</p>'; cart.forEach((it,i)=>{sum+=it.price*it.qty; const row=document.createElement('div'); row.className='cart-item'; row.innerHTML=`<div><strong>${it.name}</strong><small>${money(it.price)} cada</small></div><div class="qty"><button onclick="changeQty(${i},-1)">−</button><span>${it.qty}</span><button onclick="changeQty(${i},1)">+</button></div>`; box.appendChild(row);}); if(total)total.textContent=money(sum);}
function openCheckout(){ if(!cart.length)return toast('Adicione algum item primeiro.'); $('#checkoutModal')?.classList.add('open');}
function closeCheckout(){ $('#checkoutModal')?.classList.remove('open');}
function finishOrder(){
  if(!cart.length)return toast('Carrinho vazio.');
  const name=$('#clientName')?.value.trim()||'Cliente'; const phone=$('#clientPhone')?.value.trim()||'Não informado'; const type=$('#deliveryType')?.value||'Retirada'; const payment=$('#paymentMethod')?.value||'Pix'; const obs=$('#clientObs')?.value.trim()||'Sem observações';
  const total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  const code='DE'+Date.now().toString().slice(-6);
  const order={code,name,phone,type,payment,obs,total,status:'Recebido',createdAt:new Date().toLocaleString('pt-BR'),items:[...cart]};
  const orders=JSON.parse(localStorage.getItem(STORAGE_ORDERS)||'[]'); orders.unshift(order); localStorage.setItem(STORAGE_ORDERS, JSON.stringify(orders));
  const items=cart.map(i=>`• ${i.qty}x ${i.name} - ${money(i.price*i.qty)}`).join('%0A');
  const msg=`Olá! Quero fazer um pedido na Doce Encanto.%0A%0APedido: ${code}%0ANome: ${name}%0ATelefone: ${phone}%0ATipo: ${type}%0APagamento: ${payment}%0A%0AItens:%0A${items}%0A%0ATotal: ${money(total)}%0AObs: ${obs}%0A%0A${payment==='Pix'?'Pagamento via Pix: usar o QR Code do site ou a chave (31) 99218-0872 - Ingrid Emanuelle Damasceno.':''}`;
  cart=[]; save(); renderCart(); closeCheckout(); window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,'_blank');
}
function toggleChat(force){ const c=$('#chatBox'); if(!c)return; if(force===true)c.classList.add('open'); else if(force===false)c.classList.remove('open'); else c.classList.toggle('open');}
function botReply(text){ const body=$('#chatBody'); if(!body)return; body.innerHTML += `<p><strong>Você:</strong> ${text}</p>`; let answer='Posso ajudar com cardápio, promoção, retirada e WhatsApp.'; const t=text.toLowerCase(); if(t.includes('sabor'))answer='Temos Brigadeiro, Oreo, Maracujá e Coco disponíveis. Morango e Uva estão indisponíveis.'; if(t.includes('promo'))answer='A promoção atual é 3 trufas por R$ 14,00.'; if(t.includes('pedido'))answer='Escolha os itens no cardápio, clique em finalizar e o WhatsApp abrirá com a mensagem pronta.'; if(t.includes('retirada'))answer='A retirada é na Rua Aletes, 78, Pindorama — portão marrom.'; body.innerHTML += `<p><strong>Encantina:</strong> ${answer}</p>`; body.scrollTop=body.scrollHeight;}
function updatePixBox(){ const box=$('#pixBox'); const method=$('#paymentMethod')?.value; if(box) box.classList.toggle('open', method==='Pix'); }
window.addEventListener('DOMContentLoaded',()=>{renderProducts();renderCart(); updatePixBox(); $('#category')?.addEventListener('change',renderProducts); $('#search')?.addEventListener('input',renderProducts); $('#paymentMethod')?.addEventListener('change',updatePixBox); $('#sendOrder')?.addEventListener('click',openCheckout); $('#heroPedido')?.addEventListener('click',openCheckout); $('#closeCheckout')?.addEventListener('click',closeCheckout); $('#finishOrder')?.addEventListener('click',finishOrder); $('#chatToggle')?.addEventListener('click',()=>toggleChat()); $('#chatSend')?.addEventListener('click',()=>{const v=$('#chatInput')?.value.trim(); if(v){botReply(v); $('#chatInput').value='';}}); document.querySelectorAll('.quick-actions button').forEach(b=>b.addEventListener('click',()=>botReply(b.dataset.msg)));});
