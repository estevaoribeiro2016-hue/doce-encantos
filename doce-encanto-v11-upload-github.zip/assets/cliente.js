const orders = JSON.parse(localStorage.getItem('de_orders_v9') || '[]');
const box = document.getElementById('clientOrders');
const money = v => Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
if(!orders.length){ box.innerHTML = '<article class="product"><h3>Nenhum pedido encontrado</h3><p>Faça um pedido pelo site para ele aparecer aqui.</p><a class="btn primary" href="../index.html#cardapio">Ver cardápio</a></article>'; }
orders.forEach(o=>{ const el=document.createElement('article'); el.className='product'; el.innerHTML=`<span class="tag ok">${o.status}</span><h3>Pedido ${o.code}</h3><p><strong>${o.name}</strong> • ${o.createdAt}</p><p>${o.items.map(i=>`${i.qty}x ${i.name}`).join('<br>')}</p><strong class="price">${money(o.total)}</strong>`; box.appendChild(el); });
