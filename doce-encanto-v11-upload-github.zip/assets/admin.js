const orders = JSON.parse(localStorage.getItem('de_orders_v9') || '[]');
const money = v => Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const orderCount = document.getElementById('orderCount');
const revenue = document.getElementById('revenue');
const list = document.getElementById('orders');
if(orderCount) orderCount.textContent = orders.length;
if(revenue) revenue.textContent = money(orders.reduce((s,o)=>s+Number(o.total||0),0));
if(list){ if(!orders.length) list.innerHTML='<article class="product"><h3>Nenhum pedido ainda</h3><p>Quando um pedido for finalizado pelo site, ele aparecerá aqui neste navegador.</p></article>'; orders.forEach(o=>{ const el=document.createElement('article'); el.className='product'; el.innerHTML=`<span class="tag ok">${o.status}</span><h3>${o.code} • ${o.name}</h3><p>${o.createdAt}</p><p>${o.items.map(i=>`${i.qty}x ${i.name}`).join('<br>')}</p><strong class="price">${money(o.total)}</strong><p>${o.type} • ${o.obs}</p>`; list.appendChild(el); }); }
