# Doce Encanto

Sistema oficial da Doce Encanto.

Versão v11:
- Site profissional estático
- Trufinha mascote enviada pelo cliente
- Carrinho local
- Checkout com Pix
- QR Code Pix
- WhatsApp com mensagem pronta
- Área do cliente local
- Central da empresa local
