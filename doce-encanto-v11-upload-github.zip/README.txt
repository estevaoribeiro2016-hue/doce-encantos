Doce Encanto v9 - base profissional estática

Arquivos principais:
- index.html: site do cliente
- assets/style.css: visual premium, trufinha 3D em CSS e responsividade
- assets/app.js: cardápio, carrinho, WhatsApp e Encantina AI local
- cliente/index.html: área do cliente local
- empresa/index.html: central da empresa local

Para publicar no GitHub:
1. Abra o repositório doce-encantos.
2. Add file > Upload files.
3. Envie index.html, assets, cliente, empresa, admin e README.txt.
4. Commit changes.
5. A Vercel fará deploy automático.

Observação: esta versão salva pedidos no localStorage do navegador. Login real, banco de dados e painel multiusuário entram na próxima etapa.
